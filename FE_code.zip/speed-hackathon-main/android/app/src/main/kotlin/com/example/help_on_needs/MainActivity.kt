package com.example.help_on_needs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
